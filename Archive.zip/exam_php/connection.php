<?php
$conn=mysqli_connect("localhost","root","root","test");

if(!$conn){
    echo "fail";
}
?>